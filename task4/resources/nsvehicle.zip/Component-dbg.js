sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.vehicle.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);